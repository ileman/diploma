# ipscan
scan lan or wan ip.

In windows, you can place it as a command in C:\Windows or C:\Windows\system32.
