Automatically identify the LAN network range, scan the current LAN & enumerate each live host

Find potential vulnerabilities for each device

Once information gathering scanning & enumeration are done, user will be redirect to prepare for exploitation.

Allow the user to specify a user list

Allow the user to specify a password list

Allow the user to create a password list

If a login service is available, Brute Force with the password list

If more than one login service is available, choose the first service

Save all the results into a report + Display general statistics + Allow the user to enter an IP address; display the relevant findings
